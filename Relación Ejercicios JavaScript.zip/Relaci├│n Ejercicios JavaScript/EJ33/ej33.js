document.addEventListener("DOMContentLoaded", function () {
    const formulario = document.getElementById("formulario");

    const nacimientoSelect = document.getElementById("nacimiento");
    for (let year = 2008; year >= 1965; year--) {
        const option = document.createElement("option");
        option.value = year;
        option.textContent = year;
        nacimientoSelect.appendChild(option);
    }

    formulario.addEventListener("submit", function (event) {
        let isValid = true;

        const nombre = document.getElementById("nombre");
        const errorNombre = document.getElementById("error-nombre");
        const nombreRegex = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/;

        if (!nombreRegex.test(nombre.value)) {
            errorNombre.style.display = "inline";
            isValid = false;
        } else {
            errorNombre.style.display = "none";
        }

        const alias = document.getElementById("alias");
        const errorAlias = document.getElementById("error-alias");
        const aliasRegex = /^[a-zA-Z0-9_]{4,16}$/;

        if (!aliasRegex.test(alias.value)) {
            errorAlias.style.display = "inline";
            isValid = false;
        } else {
            errorAlias.style.display = "none";
        }

        const password = document.getElementById("password");
        const confirmPassword = document.getElementById("confirm-password");
        const errorPassword = document.getElementById("error-password");
        const errorConfirmPassword = document.getElementById("error-confirm-password");

        if (password.value.length < 6) {
            errorPassword.style.display = "inline";
            isValid = false;
        } else {
            errorPassword.style.display = "none";
        }

        if (password.value !== confirmPassword.value) {
            errorConfirmPassword.style.display = "inline";
            isValid = false;
        } else {
            errorConfirmPassword.style.display = "none";
        }

        const nacimiento = nacimientoSelect.value;
        const errorNacimiento = document.getElementById("error-nacimiento");

        if (!nacimiento) {
            errorNacimiento.style.display = "inline";
            isValid = false;
        } else {
            errorNacimiento.style.display = "none";
        }

        if (!isValid) {
            event.preventDefault();
        }
    });
});