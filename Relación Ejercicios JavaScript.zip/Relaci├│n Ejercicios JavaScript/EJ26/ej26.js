document.addEventListener("DOMContentLoaded", cargarScript);

function cargarScript() {
    let select = document.getElementById("paginasWeb");
    select.addEventListener("change", irAPagina);
    
    function irAPagina() {
        let selectOpcion = select.value;
        if (selectOpcion) {
            window.open(selectOpcion);
        }
    }
}

