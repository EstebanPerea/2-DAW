
function main() {
    let valorInput = document.getElementsByTagName("input");
    const anchoRes = screen.width;
    const altoRes = screen.height;
    let resActual = anchoRes + "x" + altoRes;
    
    for (let valores of valorInput) {
        if(valores.value == resActual) {
            valores.checked = true;
        }
    }
    
}
document.addEventListener("DOMContentLoaded", main);