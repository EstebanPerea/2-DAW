let num = prompt("Introduce el numero: ");
num = parseInt(num);
document.write("<h1> Tabla del "+ num +"</h1>");


let resultado = "";
for (let i = 1; i <= 10; i++){
    resultado = num * i;
    document.write(num + " * " + i + " = " + resultado + "</br>");
}