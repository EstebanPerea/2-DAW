let resultado = "";
for (let i = 1; i <=10; i++){

    const numero = 7;
    resultado = numero*i;
    document.write(numero + " * " + i + " = " + resultado + "</br>");
}