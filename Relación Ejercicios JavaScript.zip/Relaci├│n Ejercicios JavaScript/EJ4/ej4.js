let num = prompt("Introduce un numero de pixeles del tamaño de fuente: ");
num = parseInt(num);

let texto = prompt("Introduce el texto");

document.write("<p style= 'font-size:" + num + "px'>" + texto + "</p>");