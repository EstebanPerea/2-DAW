let num = prompt("Introduce el numero: ");
num = parseInt(num);

document.write("<table style = 'border: 1px solid black;'>");
document.write("<tr><th colspan ='5' style = 'border: 1px solid black; text-align: center; padding-left: 50px; padding-right: 50px'> Tabla del "+ num +"</th></tr>");


let resultado = "";
for (let i = 1; i <= 10; i++){
    resultado = num * i;
    document.write("<tr><td style = 'border: 1px solid black; text-align: center; padding-left: 50px; padding-right: 50px'>"+ 
        num +"</td>"+ "<td style = 'border: 1px solid black; text-align: center; padding-left: 50px; padding-right: 50px'> * </td>"+ 
        "<td style = 'border: 1px solid black; text-align: center; padding-left: 50px; padding-right: 50px'>"+ i +" </td>"+
        "<td style = 'border: 1px solid black; text-align: center; padding-left: 50px; padding-right: 50px'> = </td>"+ 
        "<td style = 'border: 1px solid black; text-align: center; padding-left: 50px; padding-right: 50px'>"+ 
        resultado +"</td>" +"</tr>");
}
document.write("</table>");