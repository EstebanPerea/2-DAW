function cambiarColor(color){
    document.body.style.backgroundColor = color;
}

document.getElementById("rojo").addEventListener("click", function(){
    cambiarColor("red");
});

document.getElementById("verde").addEventListener("click", function(){
    cambiarColor("green");
});

document.getElementById("azul").addEventListener("click", function(){
    cambiarColor("blue");
});

document.getElementById("amarillo").addEventListener("click", function(){
    cambiarColor("yellow");
});

document.getElementById("mas").addEventListener("click", function(){
    var colorActual = document.body.style.backgroundColor;

    if(colorActual === "red"){
        cambiarColor("green");
    } else if(colorActual === "green"){
        cambiarColor("blue");
    } else if(colorActual === "blue"){
        cambiarColor("yellow");
    } else if(colorActual === "yellow"){
        cambiarColor("red");
    }
});