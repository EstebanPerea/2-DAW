function cambiarColor(color){
    document.body.style.backgroundColor = color;
}

document.getElementById("rojo").addEventListener("click", function(){
    cambiarColor("red");
});

document.getElementById("verde").addEventListener("click", function(){
    cambiarColor("green");
});

document.getElementById("azul").addEventListener("click", function(){
    cambiarColor("blue");
});

document.getElementById("amarillo").addEventListener("click", function(){
    cambiarColor("yellow");
});