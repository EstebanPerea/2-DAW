
document.getElementById("rojo").addEventListener("click", function(){
    document.body.style.backgroundColor = "red";
});

document.getElementById("verde").addEventListener("click", function(){
    document.body.style.backgroundColor = "green";
});

document.getElementById("azul").addEventListener("click", function(){
    document.body.style.backgroundColor = "blue";
});

document.getElementById("amarillo").addEventListener("click", function(){
    document.body.style.backgroundColor = "yellow";
})