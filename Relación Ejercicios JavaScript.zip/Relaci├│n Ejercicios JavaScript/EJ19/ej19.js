/*
SI QUISIERA QUE ME APARECIESE LA TABLA A LA VEZ QUE EL TEXTO Y LAS FOTOS, DEBERÍA CREARME UNA VARIABLE LLAMADA 'TablaTexto' o 'TablaFoto'
QUE CONTENGA LA TABLA, ALGO TAL QUE ASÍ:

const tablaFoto = '
    table id="tablaFotos">
                <tr>
                    <td>
                        <img class="fotos">
                    </td>
                </tr>
                <tr>
                    <td>
                        <img class="fotos">
                    </td>
                </tr>
                <tr>
                    <td>
                        <img class="fotos">
                    </td>
                </tr>
            </table>
';

Y AL DIV QUE HAY FUERA DE LA TABLA PONERLE UNA ID PARA QUE ME ESCRIBA EL CONTENIDO.

*/

const frases = [
    "Esta es la primera frase de mi array. (1)",
    "Esta es la segunda frase de mi array. (2)",
    "Esta es la tercera frase de mi array. (3)",
    "Esta es la cuarta frase de mi array. (4)",
    "Esta es la quinta frase de mi array. (5)",
    "Esta es la sexta frase de mi array. (6)",
    "Esta es la septima frase de mi array. (7)",
    "Esta es la octava frase de mi array. (8)",
    "Esta es la novena frase de mi array. (9)",
    "Esta es la decima frase de mi array. (10)"
];

const fotos = [
    "./fotos/foto1.jpg",
    "./fotos/foto2.jpg",
    "./fotos/foto3.jpg",
    "./fotos/foto4.jpg",
    "./fotos/foto5.jpg"
];

function main() {
    const fraseElementos = document.getElementsByClassName("frases");
    const fotoElementos = document.getElementsByClassName("fotos");

    function cambiarFrase() {
        for (let frase of fraseElementos){
            let numTextoRandom = Math.floor(Math.random() * frases.length);
            frase.innerHTML = frases[numTextoRandom]; 
        }

        
    }

    function cambiarFoto() {
            for (let foto of fotoElementos){
                let numFotoRandom = Math.floor(Math.random() * fotos.length);
                foto.src = fotos[numFotoRandom];
            }
    }

    
    setInterval(cambiarFrase, 3000);
    setInterval(cambiarFoto, 10000);

}

document.addEventListener("DOMContentLoaded", main);