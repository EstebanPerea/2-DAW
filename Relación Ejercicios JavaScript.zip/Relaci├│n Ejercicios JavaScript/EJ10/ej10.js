botones.style.height = "200px";

document.body.style.alignItems = "center";
document.body.style.justifyContent = "center";
document.body.style.display = "flex";
document.body.style.height = "80vh";

document.getElementById("superiorizq").addEventListener("click", function(){
    ventana.style.left = "0px";
    ventana.style.top = "0px";
});

document.getElementById("superiorder").addEventListener("click", function(){
    ventana.style.left = "calc(100% - 100px)";
    ventana.style.top = "0px";
});

document.getElementById("inferiorizq").addEventListener("click", function(){
    ventana.style.left = "0px";
    ventana.style.top = "calc(100% - 100px)";
});

document.getElementById("inferiorder").addEventListener("click", function(){
    ventana.style.left = "calc(100% - 100px)";
    ventana.style.top = "calc(100% - 100px)";
});

document.getElementById("crear").addEventListener("click", function(){
    crearVentana();
});

function crearVentana(){
ventana.style.backgroundColor = "orange";
ventana.style.border = "3px solid black";
ventana.style.width = "100px";
ventana.style.height = "100px";
ventana.style.position = "absolute";
};