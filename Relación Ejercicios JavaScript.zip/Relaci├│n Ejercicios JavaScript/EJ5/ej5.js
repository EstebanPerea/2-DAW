let color = prompt("Introduce el color: ");
let tam = prompt("Introduce el tamaño de la fuente: ");
let num = prompt("Introduce el numero: ");
num = parseInt(num);
document.write("<h1> Tabla del "+ num +"</h1>");


let resultado = "";
for (let i = 1; i <= 10; i++){
    resultado = num * i;
    document.write("<p style = 'font-size:"+ tam +"px; color: " + color + "'>" + num + " * " + i + " = " + resultado + "</p>");
}