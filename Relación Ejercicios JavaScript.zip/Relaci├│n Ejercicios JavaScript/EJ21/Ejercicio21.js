const numeros = [3, 7, 1, 5, 9, 4, 6, 2, 8, 10];
const mayor = Math.max(...numeros);
const menor = Math.min(...numeros);
let resultado = '';

for (let i = 0; i < numeros.length; i++) {
    if (numeros[i] === mayor) {
        resultado += `<span class="mayor">${numeros[i]}</span>, `;
    } else if (numeros[i] === menor) {
        resultado += `<span class="menor">${numeros[i]}</span>, `;
    } else {
        resultado += `<span>${numeros[i]}</span>, `;
    }
}

document.getElementById('numeros').innerHTML = resultado;
