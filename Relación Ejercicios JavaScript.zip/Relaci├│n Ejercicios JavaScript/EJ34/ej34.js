document.addEventListener("DOMContentLoaded", function () {
    const formulario = document.getElementById("formulario");
    const botonEnviar = document.getElementById("botonenviar");

    const nacimientoSelect = document.getElementById("nacimiento");
    for (let year = 2008; year >= 1965; year--) {
        const option = document.createElement("option");
        option.value = year;
        option.textContent = year;
        nacimientoSelect.appendChild(option);
    }

    formulario.addEventListener("input", function () {
        const isValid = validarFormulario();
        botonEnviar.disabled = !isValid; 
    });

    function validarFormulario() {
        let valid = true;

        const nombre = document.getElementById("nombre");
        const errorNombre = document.getElementById("error-nombre");
        const nombreRegex = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/;

        if (!nombreRegex.test(nombre.value)) {
            errorNombre.style.display = "inline";
            valid = false;
        } else {
            errorNombre.style.display = "none";
        }

        const alias = document.getElementById("alias");
        const errorAlias = document.getElementById("error-alias");
        const aliasRegex = /^[a-zA-Z0-9_]{4,16}$/;

        if (!aliasRegex.test(alias.value)) {
            errorAlias.style.display = "inline";
            valid = false;
        } else {
            errorAlias.style.display = "none";
        }

        const password = document.getElementById("password");
        const confirmPassword = document.getElementById("confirm-password");
        const errorPassword = document.getElementById("error-password");
        const errorConfirmPassword = document.getElementById("error-confirm-password");

        if (password.value.length < 6) {
            errorPassword.style.display = "inline";
            valid = false;
        } else {
            errorPassword.style.display = "none";
        }

        if (password.value !== confirmPassword.value) {
            errorConfirmPassword.style.display = "inline";
            valid = false;
        } else {
            errorConfirmPassword.style.display = "none";
        }

        const sexo = document.querySelector('input[name="sexo"]:checked');
        const errorSexo = document.getElementById("error-sexo");

        if (!sexo) {
            errorSexo.style.display = "inline";
            valid = false;
        } else {
            errorSexo.style.display = "none";
        }

        const nacimiento = nacimientoSelect.value;
        const errorNacimiento = document.getElementById("error-nacimiento");

        if (!nacimiento) {
            errorNacimiento.style.display = "inline";
            valid = false;
        } else {
            errorNacimiento.style.display = "none";
        }

        return valid;
    }
});
