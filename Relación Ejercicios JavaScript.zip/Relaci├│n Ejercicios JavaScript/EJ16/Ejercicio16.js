document.getElementById('contarBtn').addEventListener('click', function() {
    const frase = document.getElementById('frase').value;
    let vocales = 0;
    let consonantes = 0;

    const vocalesArray = 'aeiouáéíóúAEIOUÁÉÍÓÚ';

    for (let char of frase) {
        if (/[a-zA-Z]/.test(char)) { 
            if (vocalesArray.includes(char)) {
                vocales++;
            } else {
                consonantes++;
            }
        }
    }

    document.getElementById('resultado').textContent = `Número de vocales: ${vocales}, Número de consonantes: ${consonantes}`;
});
