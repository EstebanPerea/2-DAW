let nombreNavegador = navigator.appName;
let version = navigator.appVersion;
let idioma = navigator.language;
let cpu = navigator.preference;


document.write(
    "<p><b>Nombre del navegador:</b> "+ nombreNavegador +"</p>" +
    "<p><b>Version del navegador:</b> "+ version +"</p>" +
    "<p><b>Idioma del navegador:</b> "+ idioma +"</p>" +
    "<p><b>CPU utilizada por el navegador:</b> "+ cpu +"</p>"
);