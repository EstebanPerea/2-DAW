document.addEventListener("DOMContentLoaded", cargarScript);

function cargarScript() {
    let boton = document.querySelector("button");
    boton.addEventListener("click", irAPagina);
}

function irAPagina() {
    let optionPulsado = document.querySelectorAll("option:checked");

    for (let option of optionPulsado) {
        window.open(option.value);
    }
}